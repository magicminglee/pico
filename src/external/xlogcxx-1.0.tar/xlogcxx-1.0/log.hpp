#pragma once

#include "xlog.hpp"

#define CERROR(log_fmt, ...)                                                             \
    do {                                                                                 \
        XLOG::WARN_W.Log(XLOG::XGAMELogLevel::XGAMELL_ERROR, "[%s:%d] => " log_fmt "\n", \
            __FILE__, __LINE__, ##__VA_ARGS__);                                          \
        XLOG::INFO_W.Log(XLOG::XGAMELogLevel::XGAMELL_INFO, "[%s:%d] => " log_fmt "\n",  \
            __FILE__, __LINE__, ##__VA_ARGS__);                                          \
    } while (0)

#define CWARN(log_fmt, ...)                                                                \
    do {                                                                                   \
        XLOG::WARN_W.Log(XLOG::XGAMELogLevel::XGAMELL_WARNING, "[%s:%d] => " log_fmt "\n", \
            __FILE__, __LINE__, ##__VA_ARGS__);                                            \
    } while (0)

#define CTRACE(log_fmt, ...)                                                             \
    do {                                                                                 \
        XLOG::INFO_W.Log(XLOG::XGAMELogLevel::XGAMELL_TRACE, "[%s:%d] => " log_fmt "\n", \
            __FILE__, __LINE__, ##__VA_ARGS__);                                          \
    } while (0)

#define CINFO(log_fmt, ...)                                                             \
    do {                                                                                \
        XLOG::INFO_W.Log(XLOG::XGAMELogLevel::XGAMELL_INFO, "[%s:%d] => " log_fmt "\n", \
            __FILE__, __LINE__, ##__VA_ARGS__);                                         \
    } while (0)

#define CDEBUG(log_fmt, ...)                                                             \
    do {                                                                                 \
        XLOG::INFO_W.Log(XLOG::XGAMELogLevel::XGAMELL_DEBUG, "[%s:%d] => " log_fmt "\n", \
            __FILE__, __LINE__, ##__VA_ARGS__);                                          \
    } while (0)

#define CBIGLOG(data, log_fmt, ...)                                                         \
    do {                                                                                    \
        XLOG::INFO_W.BigLog(XLOG::XGAMELogLevel::XGAMELL_INFO, data, "[%s:%d] => " log_fmt, \
            __FILE__, __LINE__, ##__VA_ARGS__);                                             \
    } while (0)
