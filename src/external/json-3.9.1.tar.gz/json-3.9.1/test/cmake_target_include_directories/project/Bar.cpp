#include "Bar.hpp"

class Bar;
