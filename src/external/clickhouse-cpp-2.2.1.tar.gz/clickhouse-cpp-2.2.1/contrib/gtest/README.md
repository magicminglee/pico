google test, version release-1.11.0, stripped.
